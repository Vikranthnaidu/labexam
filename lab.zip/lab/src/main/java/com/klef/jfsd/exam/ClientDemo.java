package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        // Configure and build session factory
        SessionFactory factory = new Configuration().configure().buildSessionFactory();

        // Insert client records
        insertClients(factory);

        // Print all records
        printAllClients(factory);

        factory.close();
    }

    private static void insertClients(SessionFactory factory) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        // Create and save persistent objects
        Client client1 = new Client();
        client1.setName("John Doe");
        client1.setGender("Male");
        client1.setAge(30);
        client1.setLocation("New York");
        client1.setEmail("johndoe@example.com");
        client1.setMobileNumber("1234567890");

        Client client2 = new Client();
        client2.setName("Jane Smith");
        client2.setGender("Female");
        client2.setAge(28);
        client2.setLocation("Los Angeles");
        client2.setEmail("janesmith@example.com");
        client2.setMobileNumber("9876543210");

        session.save(client1);
        session.save(client2);

        tx.commit();
        session.close();

        System.out.println("Clients inserted successfully!");
    }

    private static void printAllClients(SessionFactory factory) {
        Session session = factory.openSession();
        List<Client> clients = session.createQuery("from Client", Client.class).list();

        System.out.println("All Client Records:");
        for (Client client : clients) {
            System.out.println("ID: " + client.getId());
            System.out.println("Name: " + client.getName());
            System.out.println("Gender: " + client.getGender());
            System.out.println("Age: " + client.getAge());
            System.out.println("Location: " + client.getLocation());
            System.out.println("Email: " + client.getEmail());
            System.out.println("Mobile Number: " + client.getMobileNumber());
            System.out.println("-------------------------");
        }

        session.close();
    }
}
